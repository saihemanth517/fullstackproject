
function HelloWorld(){

return <h1 className="text-center">Hello world</h1>
}
export default HelloWorld;